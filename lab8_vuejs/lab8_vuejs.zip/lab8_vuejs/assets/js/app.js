const { createApp } = Vue;
const apiUrl = 'http://localhost:8080'; // sesuaikan jika public/index.php dihilangkan

createApp({
  data() {
    return {
      artikel: [],
      formData: { id: null, judul: '', isi: '', status: 0 },
      showForm: false,
      formTitle: 'Tambah Data',
      statusOptions: [
        { text: 'Draft', value: 0 },
        { text: 'Publish', value: 1 },
      ],
    };
  },
  mounted() {
    this.loadData();
  },
  methods: {
    loadData() {
      axios.get(apiUrl + '/post')
        .then(res => this.artikel = res.data.artikel)
        .catch(err => console.log(err));
    },
    statusText(status) {
      return status == 1 ? 'Publish' : 'Draft';
    },
    tambah() {
      this.formTitle = 'Tambah Data';
      this.formData = { id: null, judul: '', isi: '', status: 0 };
      this.showForm = true;
    },
    edit(data) {
      this.formTitle = 'Ubah Data';
      this.formData = { ...data };
      this.showForm = true;
    },
    hapus(index, id) {
      if (confirm('Yakin hapus data ini?')) {
        axios.delete(`${apiUrl}/post/${id}`)
          .then(() => {
            this.artikel.splice(index, 1);
          })
          .catch(err => console.log(err));
      }
    },
    saveData() {
      if (this.formData.id) {
        axios.put(`${apiUrl}/post/${this.formData.id}`, this.formData)
          .then(() => {
            this.loadData();
            console.log('Data berhasil diubah');
          })
          .catch(err => console.log(err));
      } else {
        axios.post(`${apiUrl}/post`, this.formData)
          .then(() => {
            this.loadData();
            console.log('Data berhasil ditambahkan');
          })
          .catch(err => console.log(err));
      }
      this.showForm = false;
    }

  }
}).mount('#app');
